/*
 * lcd.h
 *
 *  Created on: Jul 5, 2025
 *      Author: Matteo
 */

#ifndef INC_LCD_H_
#define INC_LCD_H_

static const char UNIVERISTY_NAME1[] = "Politechnika";
static const char UNIVERISTY_NAME2[] = "Wroclawska";
static const char COURSE_NAME[] = "PROCESORY SYGNALOWE";
static const char COURSE_LAB[] = "LAB2-3";
void init_screen()
{
	BSP_LCD_Init();
	BSP_LCD_LayerDefaultInit(0, LCD_FB_START_ADDRESS);
	BSP_LCD_SelectLayer(0);
	BSP_LCD_DisplayOn();
	BSP_LCD_Clear(LCD_COLOR_BLACK); // Clear screen
	BSP_LCD_SetBackColor(LCD_COLOR_TRANSPARENT );
	BSP_LCD_SetTextColor(LCD_COLOR_WHITE);


	BSP_LCD_DisplayStringAt(0, 100, UNIVERISTY_NAME1, CENTER_MODE);
	BSP_LCD_DisplayStringAt(0, 120, UNIVERISTY_NAME2, CENTER_MODE);
	BSP_LCD_DisplayStringAt(0, 180, COURSE_NAME, CENTER_MODE);
	BSP_LCD_DisplayStringAt(0, 200, COURSE_LAB, CENTER_MODE);
}


#endif /* INC_LCD_H_ */
