/*
 * SINE_TYLOR.h
 *
 *  Created on: Jul 6, 2025
 *      Author: Matteo
 */

#ifndef INC_SINE_TYLOR_H_
#define INC_SINE_TYLOR_H_

#define TAYLOR_TERMS 8
int16_t Sine_Taylor(float angle);

// Generowanie sinusa za pomoca szeregu Taylora
int16_t Sine_Taylor(float angle) {
    float x = fmodf(angle, 2.0f * PI);
    if (x > PI) x -= 2.0f * PI;
    float result = x;
    float term = x;
    float x2 = x * x;
    for (int i = 1; i < TAYLOR_TERMS; i++) {
        term *= -x2 / ((2 * i) * (2 * i + 1));
        result += term;
    }
    return (int16_t)(32767.0f * result);
}

#endif /* INC_SINE_TYLOR_H_ */
