/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "adc.h"
#include "crc.h"
#include "dcmi.h"
#include "dma2d.h"
#include "eth.h"
#include "fatfs.h"
#include "i2c.h"
#include "ltdc.h"
#include "quadspi.h"
#include "rtc.h"
#include "sai.h"
#include "sdmmc.h"
#include "spdifrx.h"
#include "spi.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"
#include "fmc.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stm32746g_discovery.h>
#include <stm32746g_discovery_audio.h>
#include <stm32746g_discovery_lcd.h>
#include <stm32f746xx.h>
#include <cmsis_gcc.h>
#include <sys/_stdint.h>
#include <wm8994/wm8994.h>
#include "logo.h"
#include "lcd.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
// Definicje stalych
#define ARM_MATH_CM7
#include "arm_math.h"
#define SIGNAL_LENGTH     10000 	//DLUGOSC SYGNALOW DO MNOZENIA
#define SAMPLE_RATE 	  48000  	// Czestotliwosc probkowania [Hz]
#define SINE_FREQ 		  1000		//czestotliwosc sinusa [Hz]
#define AUDIO_BUFFER_SIZE 480  		// Rozmiar bufora audio

//TODO:ODKOMENTUJ JESLI CHCESZ WYSLAC SYGNAL NA CODEC AUDIO NA WYJSCIE
//#define CODEC_OUT

#include "stm32f7xx.h"
#include "SINE_TABLE.h"
#include "SINE_CORDIC.h"
#include "SINE_TYLOR.h"
#include "FIR.h"
#include <float.h>

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
volatile bool timer_flag = 0;
uint32_t startTime, endTime, elapsedTime;
int16_t audio_buffer[AUDIO_BUFFER_SIZE];

float32_t audio_buffer1[AUDIO_BUFFER_SIZE];
float32_t audio_buffer2[AUDIO_BUFFER_SIZE];
float32_t audio_buffer3[AUDIO_BUFFER_SIZE];

int16_t audio_buffer_freq1[AUDIO_BUFFER_SIZE];
int16_t audio_buffer_freq2[AUDIO_BUFFER_SIZE];
int16_t audio_buffer_freq3[AUDIO_BUFFER_SIZE];

int16_t audio_buffer_sum[AUDIO_BUFFER_SIZE];
int16_t audio_buffer_int16[AUDIO_BUFFER_SIZE];
float filtered_buffer[AUDIO_BUFFER_SIZE];

q15_t q15_audio_buffer[AUDIO_BUFFER_SIZE]; // Buffer dla Q15, 240 probek
float32_t float_audio_buffer[AUDIO_BUFFER_SIZE]; // Buffer dla float, 120 probek
ConvDirect_Container conv;
const float ConvDirect_Kernel[CONV_LENGTH] =
{	0.002174, 0.002857, 0.004179, 0.006112, 0.008625, 0.011686, 0.015231,
	0.019183, 0.023439, 0.027885, 0.032387, 0.036787, 0.040904, 0.044535,
	0.047561, 0.049846, 0.051239, 0.051649, 0.051239, 0.049846, 0.047561,
	0.044535, 0.040904, 0.036787, 0.032387, 0.027885, 0.023439, 0.019183,
	0.015231, 0.011686, 0.008625, 0.006112, 0.004179, 0.002857, 0.002174
};


/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
void PeriphCommonClock_Config(void);
/* USER CODE BEGIN PFP */
void GenerateSineWave(int16_t* buffer, uint32_t size, int16_t (*sine_func)(float));

uint16_t * convert_q15_to_uint16_t(q15_t *buff_q15);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/**
 * \Funkcja do wysylania po serial porcie danych np o czasie wykonania funkcji
 */
int __io_putchar(int ch)
{
    if (ch == '\n') {
        uint8_t ch2 = '\r';
        HAL_UART_Transmit(&huart1, &ch2, 1, HAL_MAX_DELAY);
    }
    HAL_UART_Transmit(&huart1, (uint8_t*)&ch, 1, HAL_MAX_DELAY);
    return 1;
}

void sum_buffers_into_larger_buffer(void) {
    for (int i = 0; i < AUDIO_BUFFER_SIZE; i++) {
        float32_t sum = (float32_t)audio_buffer_freq1[i] +
                        (float32_t)audio_buffer_freq2[i] +
                        (float32_t)audio_buffer_freq3[i];

        // Clip to float32 range (extremely unlikely needed)
        if (sum > FLT_MAX) sum = FLT_MAX;
        if (sum < -FLT_MAX) sum = -FLT_MAX;

        audio_buffer_sum[i] = sum;
    }
}

void convert_float_to_int16(const float32_t* in, int16_t* out, size_t size) {
    for (size_t i = 0; i < size; i++) {
        float32_t sample = in[i];

        // Clamp to [-1.0, 1.0]
        if (sample > 1.0f) sample = 1.0f;
        if (sample < -1.0f) sample = -1.0f;

        // Scale and convert
        out[i] = (int16_t)(sample * INT16_MAX);
    }
}



/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */
  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* Configure the peripherals common clocks */
  PeriphCommonClock_Config();

  /* USER CODE BEGIN SysInit */
  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_ADC3_Init();
  MX_CRC_Init();
  MX_DCMI_Init();
  MX_DMA2D_Init();
  MX_ETH_Init();
  MX_FMC_Init();
  MX_I2C1_Init();
  MX_I2C3_Init();
  MX_LTDC_Init();
  MX_QUADSPI_Init();
  MX_RTC_Init();
  MX_SAI2_Init();
  MX_SDMMC1_SD_Init();
  MX_SPDIFRX_Init();
  MX_SPI2_Init();
  MX_TIM1_Init();
  MX_TIM2_Init();
  MX_TIM3_Init();
  MX_TIM5_Init();
  MX_TIM8_Init();
  MX_TIM12_Init();
  MX_USART1_UART_Init();
  MX_USART6_UART_Init();
  MX_FATFS_Init();
  MX_TIM7_Init();
  /* USER CODE BEGIN 2 */
  BSP_LED_Init(LED1);
  //NVIC_DisableIRQ(TIM6_DAC_IRQn); // TODO:ODKOMENTUJ DO DEBUGOWANIA
  init_screen();
  if (BSP_AUDIO_OUT_Init(OUTPUT_DEVICE_HEADPHONE, 80, 16000) != AUDIO_OK)
  {
	  BSP_LED_Toggle(LED1);
      HAL_Delay(100);
      BSP_LED_Toggle(LED1);
      while (1);
   }

  HAL_TIM_Base_Start(&htim7);
  __HAL_TIM_SET_COUNTER(&htim7, 0);
  startTime = __HAL_TIM_GET_COUNTER(&htim7);
  GenerateSineWave(audio_buffer, AUDIO_BUFFER_SIZE, Sine_LookupTable);
  endTime = __HAL_TIM_GET_COUNTER(&htim7);
  elapsedTime = endTime - startTime;
  HAL_TIM_Base_Stop(&htim7);
  printf("Czas generacji sinusa lookup_table %lu us\n", elapsedTime);

  HAL_TIM_Base_Start(&htim7);
  __HAL_TIM_SET_COUNTER(&htim7, 0);
  startTime = __HAL_TIM_GET_COUNTER(&htim7);
  GenerateSineWave(audio_buffer, AUDIO_BUFFER_SIZE, Sine_Taylor);
  endTime = __HAL_TIM_GET_COUNTER(&htim7);
  elapsedTime = endTime - startTime;
  HAL_TIM_Base_Stop(&htim7);
  printf("Czas generacji sinusa Sine_Taylor %lu us\n", elapsedTime);

  HAL_TIM_Base_Start(&htim7);
  __HAL_TIM_SET_COUNTER(&htim7, 0);
  startTime = __HAL_TIM_GET_COUNTER(&htim7);
  GenerateSineWave(audio_buffer, AUDIO_BUFFER_SIZE, Sine_CORDIC);
  endTime = __HAL_TIM_GET_COUNTER(&htim7);
  elapsedTime = endTime - startTime;
  HAL_TIM_Base_Stop(&htim7);
  printf("Czas generacji sinusa Sine_CORDIC %lu us\n", elapsedTime);


  HAL_TIM_Base_Start(&htim7);
  __HAL_TIM_SET_COUNTER(&htim7, 0);
  startTime = __HAL_TIM_GET_COUNTER(&htim7);
  for (uint32_t i = 0; i < AUDIO_BUFFER_SIZE; i++) {
      q15_t phase = (q15_t)((0x7FFF * i * 2 * PI) / (AUDIO_BUFFER_SIZE * 2 * PI)); // krok = 2π/AUDIO_BUFFER_SIZE
      q15_audio_buffer[i] = arm_sin_q15(phase);
  }
  endTime = __HAL_TIM_GET_COUNTER(&htim7);
  elapsedTime = endTime - startTime;
  HAL_TIM_Base_Stop(&htim7);
  printf("Czas generacji sinusa CMSIS_Q15 %lu us\n", elapsedTime);

  HAL_TIM_Base_Start(&htim7);
  __HAL_TIM_SET_COUNTER(&htim7, 0);
  startTime = __HAL_TIM_GET_COUNTER(&htim7);
  for (uint32_t i = 0; i < AUDIO_BUFFER_SIZE; i++) {
      float32_t phase = (i * 2 * PI) / AUDIO_BUFFER_SIZE; // krok = 2π/AUDIO_BUFFER_SIZE
      float_audio_buffer[i] = arm_sin_f32(phase);
  }
  endTime = __HAL_TIM_GET_COUNTER(&htim7);
  elapsedTime = endTime - startTime;
  HAL_TIM_Base_Stop(&htim7);
  printf("Czas generacji sinusa CMSIS_Float %lu us\n", elapsedTime);

  ConvDirect_init(&conv, ConvDirect_Kernel);

#ifdef CODEC_SINE_OUT
sum_buffers_into_larger_buffer();
ConvDirect_init(&conv, ConvDirect_Kernel);
for (int block = 0; block < 4; block++)
{
	int start_idx = block * BLOCK_SIZE;
	ConvDirect_Update(&conv, &audio_buffer_sum[start_idx]);
	for (int i = 0; i < BLOCK_SIZE; i++)
	{
		filtered_buffer[start_idx + i] = conv.out[i];
	}
}
convert_float_to_int16(filtered_buffer, audio_buffer_int16, AUDIO_BUFFER_SIZE);
#endif

#ifdef CODEC_SIG_IN

#endif
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
	  BSP_LED_Toggle(LED1);
	  if (BSP_AUDIO_OUT_Play((uint16_t*)audio_buffer_int16, AUDIO_BUFFER_SIZE * sizeof(uint16_t)) != AUDIO_OK)
	  {
	  BSP_LED_Off(LED1);
	  while (1);
	  }

	  HAL_Delay(250);
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure LSE Drive Capability
  */
  HAL_PWR_EnableBkUpAccess();

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_LSI|RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.LSIState = RCC_LSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 25;
  RCC_OscInitStruct.PLL.PLLN = 400;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Activate the Over-Drive mode
  */
  if (HAL_PWREx_EnableOverDrive() != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_6) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief Peripherals Common Clock Configuration
  * @retval None
  */
void PeriphCommonClock_Config(void)
{
  RCC_PeriphCLKInitTypeDef PeriphClkInitStruct = {0};

  /** Initializes the peripherals clock
  */
  PeriphClkInitStruct.PeriphClockSelection = RCC_PERIPHCLK_LTDC|RCC_PERIPHCLK_SAI2
                              |RCC_PERIPHCLK_SDMMC1|RCC_PERIPHCLK_CLK48;
  PeriphClkInitStruct.PLLSAI.PLLSAIN = 384;
  PeriphClkInitStruct.PLLSAI.PLLSAIR = 5;
  PeriphClkInitStruct.PLLSAI.PLLSAIQ = 2;
  PeriphClkInitStruct.PLLSAI.PLLSAIP = RCC_PLLSAIP_DIV8;
  PeriphClkInitStruct.PLLSAIDivQ = 1;
  PeriphClkInitStruct.PLLSAIDivR = RCC_PLLSAIDIVR_8;
  PeriphClkInitStruct.Sai2ClockSelection = RCC_SAI2CLKSOURCE_PLLSAI;
  PeriphClkInitStruct.Clk48ClockSelection = RCC_CLK48SOURCE_PLLSAIP;
  PeriphClkInitStruct.Sdmmc1ClockSelection = RCC_SDMMC1CLKSOURCE_CLK48;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */
void GenerateSineWave(int16_t* buffer, uint32_t size, int16_t (*sine_func)(float)) {
    float phase_step = 2.0f * PI * SINE_FREQ / SAMPLE_RATE;
    float phase = 0.0f;

    for (uint32_t i = 0; i < size; i++) {
        buffer[i] = sine_func(phase); // Use raw value directly
        phase += phase_step;
        if (phase >= 2.0f * PI) phase -= 2.0f * PI;
    }
}

void BSP_AUDIO_OUT_TransferComplete_CallBack()
{
	printf("Wyslano sygnal audio do Codeca\n");
	BSP_LED_Toggle(LED1);
}

/* USER CODE END 4 */

/**
  * @brief  Period elapsed callback in non blocking mode
  * @note   This function is called  when TIM6 interrupt took place, inside
  * HAL_TIM_IRQHandler(). It makes a direct call to HAL_IncTick() to increment
  * a global variable "uwTick" used as application time base.
  * @param  htim : TIM handle
  * @retval None
  */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
  /* USER CODE BEGIN Callback 0 */

  /* USER CODE END Callback 0 */
  if (htim->Instance == TIM6)
  {
    HAL_IncTick();
  }

  /* USER CODE BEGIN Callback 1 */

  /* USER CODE END Callback 1 */
}

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
