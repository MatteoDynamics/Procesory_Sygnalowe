/*
 * audio_init.h
 *
 *  Created on: Jul 6, 2025
 *      Author: Matteo
 */

#ifndef INC_AUDIO_INIT_H_
#define INC_AUDIO_INIT_H_

void audio_init()
{

}


#endif /* INC_AUDIO_INIT_H_ */
