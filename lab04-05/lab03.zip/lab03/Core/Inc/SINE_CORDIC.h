/*
 * SINE_CORDIC.h
 *
 *  Created on: Jul 6, 2025
 *      Author: Matteo
 */

#ifndef INC_SINE_CORDIC_H_
#define INC_SINE_CORDIC_H_

#define CORDIC_ITERATIONS 6
const float cordic_gain = 0.607252935; // Stala skalujaca CORDIC

const float cordic_angles[CORDIC_ITERATIONS] = {
    0.785398163,
	0.463647609,
	0.244978663,
	0.124354994,
	0.06241881,
	0.031239833,
};

int16_t Sine_CORDIC(float theta);

int16_t Sine_CORDIC(float theta) {
    while (theta >= 2.0f * PI) theta -= 2.0f * PI;
    while (theta < 0.0f) theta += 2.0f * PI;

    float angle;
    int8_t sign_sin = 1, sign_cos = 1;

    if (theta >= 0.0f && theta < PI / 2.0f) {
        angle = theta;
        sign_sin = 1;
        sign_cos = 1;
    } else if (theta >= PI / 2.0f && theta < PI) {
        angle = PI - theta;
        sign_sin = 1;
        sign_cos = -1;
    } else if (theta >= PI && theta < 3.0f * PI / 2.0f) {
        angle = theta - PI;
        sign_sin = -1;
        sign_cos = -1;
    } else {
        angle = 2.0f * PI - theta;
        sign_sin = -1;
        sign_cos = 1;
    }

    float x = cordic_gain;
    float y = 0.0f;
    float z = angle;

    for (uint8_t i = 0; i < CORDIC_ITERATIONS; i++) {
        float dx = x * (1.0f / (1 << i));
        float dy = y * (1.0f / (1 << i));
        if (z >= 0.0f) {
            x -= dy;
            y += dx;
            z -= cordic_angles[i];
        } else {
            x += dy;
            y -= dx;
            z += cordic_angles[i];
        }
    }

    return (int16_t)(sign_sin * y * 32767.0f);
}

#endif /* INC_SINE_CORDIC_H_ */
