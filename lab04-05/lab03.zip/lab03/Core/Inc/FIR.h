/*
 * FIR.h
 *
 *  Created on: Jul 6, 2025
 *      Author: Matteo
 */

#ifndef INC_FIR_H_
#define INC_FIR_H_

#define ARM_MATH_CM7
#include "arm_math.h"
				//czestotliwosc sinusa [Hz]
#define CONV_LENGTH 33					// Rozmiar bufora audio
#define BLOCK_SIZE 		  (AUDIO_BUFFER_SIZE/4) //block to process by FIR

typedef struct
{
	arm_fir_instance_f32 firProcessor;
	float firBuf[CONV_LENGTH+BLOCK_SIZE-1];
	float kernelTimeReversed[CONV_LENGTH];
	float out[BLOCK_SIZE];
}ConvDirect_Container;

extern const float ConvDirect_Kernel[CONV_LENGTH];

void ConvDirect_init(ConvDirect_Container *cont, const float * kernel);
void COnvDirect_Update(ConvDirect_Container *cont, float * input);

void ConvDirect_init(ConvDirect_Container *cont, const float * kernel)
{
	uint32_t index;
	for (index = 0; index<CONV_LENGTH; index++)
	{
		cont->kernelTimeReversed[index] = kernel[CONV_LENGTH-index - 1];
	}
	arm_fir_init_f32(&(cont->firProcessor), CONV_LENGTH, cont->kernelTimeReversed,cont->firBuf, BLOCK_SIZE);
}

void ConvDirect_Update(ConvDirect_Container *cont, float * input)
{
	arm_fir_f32(&(cont->firProcessor), input, cont->out, BLOCK_SIZE);
}
#endif /* INC_FIR_H_ */
